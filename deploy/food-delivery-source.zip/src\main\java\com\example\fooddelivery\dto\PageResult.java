package com.example.fooddelivery.dto;

import lombok.Data;
import java.util.ArrayList;
import java.util.List;

@Data
public class PageResult<T> {
    private List<T> list = new ArrayList<>();
    private long total;
    private int page;
    private int pageSize;

    public PageResult() {
    }

    public PageResult(List<T> list, long total, int page, int pageSize) {
        this.list = list;
        this.total = total;
        this.page = page;
        this.pageSize = pageSize;
    }
}
